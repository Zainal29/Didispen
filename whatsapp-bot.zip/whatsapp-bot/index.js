const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const express = require('express');
const pino = require('pino');
const fs = require('fs');
const path = require('path');
const qrcodeTerminal = require('qrcode-terminal');
const QRCode = require('qrcode');

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3789;
const API_KEY = process.env.WA_BOT_API_KEY || 'sipintu_wa_secret_key_2026';

let sock = null;
let qrCodeData = null;
let qrCodeImage = null;
let connectionStatus = 'disconnected'; // 'disconnected' | 'connecting' | 'connected'
let connectedUser = null;
const authFolder = path.join(__dirname, 'auth_info_baileys');

// Middleware Autentikasi API Key
app.use((req, res, next) => {
    const apiKey = req.headers['x-api-key'] || req.query.api_key;
    if (!apiKey || apiKey !== API_KEY) {
        return res.status(401).json({ error: 'Unauthorized: Invalid API Key' });
    }
    next();
});

async function connectToWhatsApp() {
    connectionStatus = 'connecting';
    try {
        const { state, saveCreds } = await useMultiFileAuthState(authFolder);

        sock = makeWASocket({
            auth: state,
            logger: pino({ level: 'silent' }),
            browser: ['Didispen Admin', 'Chrome', '1.0.0']
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr) {
                qrCodeData = qr;
                connectionStatus = 'waiting_qr';
                try {
                    qrCodeImage = await QRCode.toDataURL(qr, {
                        width: 320,
                        margin: 2,
                        color: {
                            dark: '#0f172a',
                            light: '#ffffff'
                        }
                    });
                } catch (err) {
                    console.error('Gagal generate QR Code Image:', err);
                }

                console.log('📱 QR Code baru dibuat. Scan via WhatsApp Anda atau via Web Admin Dashboard:');
                qrcodeTerminal.generate(qr, { small: true });
            }

            if (connection === 'close') {
                const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
                connectionStatus = 'disconnected';
                connectedUser = null;
                qrCodeData = null;
                qrCodeImage = null;

                console.log('⚠️ Koneksi terputus. Alasan:', lastDisconnect?.error?.message || 'Unknown');
                if (shouldReconnect) {
                    console.log('🔄 Mencoba menghubungkan kembali dalam 3 detik...');
                    setTimeout(connectToWhatsApp, 3000);
                } else {
                    console.log('🚪 Sesi logout. Menunggu inisialisasi baru...');
                }
            } else if (connection === 'open') {
                connectionStatus = 'connected';
                qrCodeData = null;
                qrCodeImage = null;

                const userJid = sock.user?.id || '';
                const cleanPhone = userJid.split(':')[0].replace('@s.whatsapp.net', '');
                connectedUser = {
                    id: userJid,
                    phone: cleanPhone,
                    name: sock.user?.name || 'Bot WhatsApp Didispen'
                };

                console.log(`✅ Bot WhatsApp Baileys Terhubung! Akun: ${connectedUser.phone} (${connectedUser.name})`);
            }
        });
    } catch (err) {
        console.error('Error saat inisialisasi Baileys:', err);
        connectionStatus = 'disconnected';
        setTimeout(connectToWhatsApp, 5000);
    }
}

// 1. Endpoint Cek Status & Info Bot
app.get('/status', (req, res) => {
    res.json({
        online: true,
        connected: connectionStatus === 'connected',
        status: connectionStatus,
        user: connectedUser,
        qr: qrCodeData,
        qr_image: qrCodeImage,
        message: connectionStatus === 'connected'
            ? `Bot Terhubung ke WhatsApp (${connectedUser?.phone || ''})`
            : (connectionStatus === 'waiting_qr' ? 'Menunggu Scan QR Code' : 'Bot Sedang Mempersiapkan Koneksi')
    });
});

// 2. Endpoint Khusus Ambil QR Code (JSON / Image)
app.get('/qr', (req, res) => {
    res.json({
        connected: connectionStatus === 'connected',
        status: connectionStatus,
        qr: qrCodeData,
        qr_image: qrCodeImage
    });
});

// 3. Endpoint Kirim Pesan WhatsApp
app.post('/send-message', async (req, res) => {
    try {
        const { phone, message } = req.body;

        if (!phone || !message) {
            return res.status(400).json({ error: 'Parameter phone dan message wajib diisi.' });
        }

        if (connectionStatus !== 'connected' || !sock) {
            return res.status(503).json({
                error: 'WhatsApp socket belum terhubung. Silakan scan QR Code terlebih dahulu melalui panel admin.'
            });
        }

        // Format nomor ke JID WhatsApp (e.g. 628123456789 -> 628123456789@s.whatsapp.net)
        let clean = phone.replace(/[^0-9]/g, '');
        if (clean.startsWith('0')) {
            clean = '62' + clean.slice(1);
        }
        const jid = `${clean}@s.whatsapp.net`;

        const result = await sock.sendMessage(jid, { text: message });

        return res.json({
            status: 'success',
            message: 'Pesan berhasil dikirim via Baileys.',
            message_id: result.key.id
        });
    } catch (error) {
        console.error('Gagal kirim pesan WhatsApp:', error);
        return res.status(500).json({ error: error.message });
    }
});

// 4. Endpoint Logout / Putuskan Sesi
app.post('/logout', async (req, res) => {
    try {
        console.log('🧹 Permintaan logout diterima dari Admin...');
        if (sock) {
            try {
                await sock.logout();
            } catch (e) {}
        }
        // Hapus folder auth_info_baileys
        if (fs.existsSync(authFolder)) {
            fs.rmSync(authFolder, { recursive: true, force: true });
        }
        connectionStatus = 'disconnected';
        connectedUser = null;
        qrCodeData = null;
        qrCodeImage = null;

        // Reconnect agar siap scan QR baru
        setTimeout(connectToWhatsApp, 1500);

        return res.json({ status: 'success', message: 'Sesi WhatsApp berhasil diputuskan. QR Code baru sedang disiapkan.' });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
});

// 5. Endpoint Restart Koneksi
app.post('/restart', (req, res) => {
    try {
        console.log('🔄 Merestart socket Baileys...');
        if (sock) {
            sock.end();
        }
        connectionStatus = 'connecting';
        setTimeout(connectToWhatsApp, 1000);
        return res.json({ status: 'success', message: 'Socket Baileys sedang direstart.' });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`🚀 Baileys Bot REST API berjalan di port ${PORT}`);
    console.log(`🔑 Endpoint API Key dilindungi oleh header: x-api-key`);
    connectToWhatsApp();
});
